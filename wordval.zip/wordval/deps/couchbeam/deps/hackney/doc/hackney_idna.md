

# Module hackney_idna #
* [Function Index](#index)
* [Function Details](#functions)

<a name="index"></a>

## Function Index ##


<table width="100%" border="1" cellspacing="0" cellpadding="2" summary="function index"><tr><td valign="top"><a href="#to_ascii-1">to_ascii/1</a></td><td>encode a IDNA domain to ascii.</td></tr></table>


<a name="functions"></a>

## Function Details ##

<a name="to_ascii-1"></a>

### to_ascii/1 ###

`to_ascii(Domain) -> any()`

encode a IDNA domain to ascii

