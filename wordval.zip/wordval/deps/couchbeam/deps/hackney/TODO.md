# TODO

todo of hackney

- Add Websockets support
- Add SPDY support
- Add HTTP pipelines support
- Add support for custom authentication methods
- Add support for oauth2 ?
- Add support for HTTP digest auth
