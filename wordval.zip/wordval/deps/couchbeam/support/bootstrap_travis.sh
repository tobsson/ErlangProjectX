#!/bin/sh

curl -O -L https://s3.amazonaws.com/rebar3/rebar3
chmod +x rebar3
./rebar3 update